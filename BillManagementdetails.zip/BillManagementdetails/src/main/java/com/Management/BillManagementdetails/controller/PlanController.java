package com.Management.BillManagementdetails.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.Management.BillManagementdetails.dto.PlanCrtDto;
import com.Management.BillManagementdetails.dto.PlanGetDto;
import com.Management.BillManagementdetails.dto.ResponseDto;
import com.Management.BillManagementdetails.dto.UsageGetDto;
import com.Management.BillManagementdetails.service.PlanService;

@RestController
@RequestMapping("plans/")
public class PlanController {

	@Autowired
	PlanService planService;

	public static final Logger logger = LogManager.getLogger(PlanController.class);

	@PostMapping(path = "addplan", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> addPlan(@RequestBody PlanCrtDto planCrtDto) {
		ResponseDto response = null;
		try {
			logger.info("{} >> planCrtDto:[{}],", planCrtDto);
			long id = planService.savePlans(planCrtDto);
			if (id > 0) {
				response = new ResponseDto(id, "Plan created successfully");
				logger.info("{} << response:[{}]", response);
				return new ResponseEntity<>(response, HttpStatus.CREATED);
			} else {
				response = new ResponseDto(id, "Plan created failed");
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			logger.error("Error saving Plan", e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(path = "getallplans", produces = { "application/json", "application/xml" })
	public ResponseEntity<List<PlanGetDto>> getAllPlans() {
		try {
			List<PlanGetDto> response = planService.getAllPlans();
			logger.info("{} <<:getallplans:Response:{}", response);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception:{}", e.getMessage());
			return ResponseEntity.status(HttpStatus.OK).body(new ArrayList<>());
		}
	}
	
	@DeleteMapping(path = "deleteplan/{id}", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> deletePlan(@PathVariable("id") Long id) {
		ResponseDto response = null;
		try {
			long planId = planService.deletePlanById(id);
			if (planId > 0) {
				response = new ResponseDto(id, "Plan deleted Successfully");
				logger.info("{} <<:deletePlan:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else {
				response = new ResponseDto(id, "Customer fail to delete");
				logger.info("{} <<:deletePlan:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
		}
	}
	
	@PutMapping(path = "updatecustomer/{customerId}", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> updateplan(@RequestBody PlanGetDto updateDto) {
		ResponseDto response = null;
		try {
			long id = planService.updatePlan(updateDto);
			if (id > 0) {
				response = new ResponseDto(id, "Plan update Successfully");
				logger.info("{} <<:update:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else {
				response = new ResponseDto(id, "Plan update failed");
				logger.info("{} <<:update:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
		}
	}
	@GetMapping(path = "/getById/{id}", produces = { "application/json", "application/xml" })
    public ResponseEntity<PlanGetDto> getPlansById(@PathVariable("id")  Long id) {
        try {
        	PlanGetDto response = planService.getPlansById(id);
            if (response != null) {
                logger.info(">>getPlansById:[{}]", response);
                return ResponseEntity.status(HttpStatus.OK).body(response);
            } else {
                logger.info("{} <<:getPlansById:Response:{}", response);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
	
}
