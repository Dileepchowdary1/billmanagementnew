package com.Management.BillManagementdetails.dto;

public class ResponseDto {
	
	private Long id;
	private String message;
	
	public ResponseDto(Long id, String message) {
		super();
		this.id = id;
		this.message = message;
	}
	
	public ResponseDto() {
		super();
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "Response [id=" + id + ", message=" + message + "]";
	}
	

}
