package com.Management.BillManagementdetails.service;


import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.Management.BillManagementdetails.dto.PlanCrtDto;
import com.Management.BillManagementdetails.dto.PlanGetDto;
import com.Management.BillManagementdetails.dto.UsageGetDto;
import com.Management.BillManagementdetails.entity.Plan;
import com.Management.BillManagementdetails.entity.Usage;
import com.Management.BillManagementdetails.mapper.Mapper;
import com.Management.BillManagementdetails.repository.PlanRepository;

@Service
public class PlanService {

	public static final Logger logger = LogManager.getLogger(UsageService.class);
	
	@Autowired
	PlanRepository planRepository;
	
	public long savePlans(PlanCrtDto planDto) {
		
		try {
//			plan = Mapper.INSTANCE.planCrtDtoToPlanEntity(crtDto);
			Plan plan =new Plan();
            plan.setStdCallCharges(planDto.getStdCallCharges());
            plan.setQuantityStdCall(planDto.getQuantityStdCall());
            plan.setUnitStdCall(planDto.getUnitStdCall());
            plan.setFreeUnitStdCall(planDto.getFreeUnitStdCall());
            plan.setIsdCallCharges(planDto.getIsdCallCharges());
            plan.setQuantityIsdCall(planDto.getQuantityIsdCall());
            plan.setUnitIsdCall(planDto.getUnitIsdCall());
            plan.setFreeUnitIsdCall(planDto.getFreeUnitIsdCall());
            plan.setStdSmsCharges(planDto.getStdSmsCharges());
            plan.setFreeUnitStdSms(planDto.getFreeUnitStdSms());
            plan.setIsdSmsCharges(planDto.getIsdSmsCharges());
            plan.setFreeUnitIsdSms(planDto.getFreeUnitIsdSms());
            plan.setDataCharges(planDto.getDataCharges());
            plan.setDataChargesUnit(planDto.getDataChargesUnit());
            plan.setFreeUnitData(planDto.getFreeUnitData());
            planRepository.save(plan);
			logger.info("{} << response:[{}]", plan);
			return plan.getPlanId();
		} catch (Exception e) {
			logger.error("Error saving Plan", e.getMessage());
			return 0;
		}
	}

	public List<PlanGetDto> getAllPlans() {
		try {
			List<Plan> allPlans = planRepository.findAll();
			List<PlanGetDto> response = Mapper.INSTANCE.getAllPlansToEntity(allPlans);
			logger.info("{} <<:getAllPlans:Response:{}", response);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return new ArrayList<>();
		}
	}
	public long deletePlanById(Long id) {
		try {
			logger.info("{} >> deletePlanById:[{}],", id);
			planRepository.deleteById(id);
			return id;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}
	
	public long updatePlan(PlanGetDto updateDto) {
		Plan plan = null;
		try {
			if (updateDto.getPlanId() != null && updateDto.getPlanId() > 0) {
				plan = planRepository.getOne(updateDto.getPlanId());
			}
			if (plan != null) {
				Plan planDto = Mapper.INSTANCE.updateDtoToPlan(updateDto);
				logger.info("{}<<:updatePlan:[{}]", planDto);
				planDto = planRepository.saveAndFlush(planDto);
				return planDto.getPlanId();
			} else {
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}

	public PlanGetDto getPlansById(Long id) {
		try {
			PlanGetDto response = planRepository.getPlansByPlanId(id);
				logger.info("{} <<:getPlansById:Response:{}", response);
				return response;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return null;
		}
	}
}
