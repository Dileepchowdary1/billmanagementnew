package com.Management.BillManagementdetails.dto;

import java.util.Date;

public class UsageCrtDto {

	
	private Long customerId;
    private String usageType;
    private String measurementUnit;
    private String phoneNumber;
    private Double quantity;
    private Date timestamp;
	public UsageCrtDto() {
		super();
	}
	public UsageCrtDto(Long customerId, String usageType, String measurementUnit, String phoneNumber, Double quantity,
			Date timestamp) {
		super();
		this.customerId = customerId;
		this.usageType = usageType;
		this.measurementUnit = measurementUnit;
		this.phoneNumber = phoneNumber;
		this.quantity = quantity;
		this.timestamp = timestamp;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public String getUsageType() {
		return usageType;
	}
	public void setUsageType(String usageType) {
		this.usageType = usageType;
	}
	public String getMeasurementUnit() {
		return measurementUnit;
	}
	public void setMeasurementUnit(String measurementUnit) {
		this.measurementUnit = measurementUnit;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Double getQuantity() {
		return quantity;
	}
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	public Date getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}
	@Override
	public String toString() {
		return "UsageCrtDto [customerId=" + customerId + ", usageType=" + usageType + ", measurementUnit="
				+ measurementUnit + ", phoneNumber=" + phoneNumber + ", quantity=" + quantity + ", timestamp="
				+ timestamp + "]";
	}
    
}
