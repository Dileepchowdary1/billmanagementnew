package com.Management.BillManagementdetails.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Management.BillManagementdetails.dto.BillGetDto;
import com.Management.BillManagementdetails.dto.PaymentDto;
import com.Management.BillManagementdetails.entity.Bill;
import com.Management.BillManagementdetails.entity.Customer;
import com.Management.BillManagementdetails.entity.Usage;
import com.Management.BillManagementdetails.mapper.Mapper;
import com.Management.BillManagementdetails.repository.BillRepository;
import com.Management.BillManagementdetails.repository.CustomerRepo;
import com.Management.BillManagementdetails.repository.PlanRepository;
import com.Management.BillManagementdetails.repository.UsageRepository;

@Service
public class BillService {

	public static final Logger logger = LogManager.getLogger(BillService.class);

	@Autowired
	BillRepository billRepository;

	@Autowired
	PlanRepository planRepository;

	@Autowired
	UsageRepository usageRepository;

	@Autowired
	CustomerRepo customerRepository;


	public long generateBill(Long customerId) {
		try {
			Customer customer = customerRepository.getOne(customerId);
			if (customer.getCustomerId() > 0) {
				LocalDate currentDate = LocalDate.now();
				LocalDate firstDayOfMonth = currentDate.withDayOfMonth(1);
				LocalDate lastDayOfMonth = currentDate.withDayOfMonth(currentDate.lengthOfMonth());
				List<Bill> existingBills = billRepository.findByCustomerAndDueDateBetween(customer,
						Date.valueOf(firstDayOfMonth), Date.valueOf(lastDayOfMonth));
				if (!existingBills.isEmpty()) {
					logger.info("{} <<:getAllBills:Response:{}", " Bill already generated for the current month");
					return 0;
				}
				double totalUsageCharges = calculateTotalUsageCharges(customer);
				double arrears = calculateArrears(customer);
				double penalty = 0.1 * arrears;
				double billAmount = totalUsageCharges + arrears + penalty;
				Bill bill = new Bill();
				bill.setCustomer(customer);
				bill.setBillAmount(billAmount);
				bill.setDueDate(Date.valueOf(lastDayOfMonth));
				Bill savedBill = billRepository.save(bill);
				return savedBill.getBillId();
			} else {
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	private double calculateTotalUsageCharges(Customer customer) {
		List<Usage> customerUsages = customer.getUsages();
		double totalUsageCharges = 0.0;

		for (Usage usage : customerUsages) {
			double usageCharge = calculateUsageCharge(usage);
			totalUsageCharges += usageCharge;
		}

		return totalUsageCharges;
	}

	private double calculateUsageCharge(Usage usage) {
		double quantity = usage.getQuantity();
		String measurementUnit = usage.getMeasurementUnit();
		String usageType = usage.getUsageType();
		double chargePerUnit = getChargePerUnit(usageType);
		return quantity * chargePerUnit;
	}

	private double getChargePerUnit(String usageType) {
		switch (usageType) {
		case "std call":
			return 0.1;
		case "unit std call":
			return 0.15;
		case "free unit std call":
			return 0.0;
		case "isd call charges":
			return 0.5;
		case "quantity isd call":
			return 0.8;
		case "unit isd call":
			return 0.6;
		case "free unit isd call":
			return 0.0;
		case "std sms charges":
			return 0.02;
		case "free unit std sms":
			return 0.0;
		case "isd sms charges":
			return 0.1;
		case "free unit isd sms":
			return 0.0;
		case "data charges":
			return 0.3;
		case "data charges unit":
			return 0.01;
		case "free unit data":
			return 0.0;
		default:
			return 0.0;
		}
	}

	public double calculateArrears(Customer customer) {
	    try {
	        Bill latestBill = billRepository.findBillForCustomer(customer);
	        if (latestBill != null) {
	            double arrears = Math.max(0, latestBill.getBillAmount() - latestBill.getPaymentAmount());
	            logger.info("Arrears calculated for customer {}: {}", customer.getCustomerId(), arrears);
	            return arrears;
	        } else {
	            logger.info("No previous bills found for customer {}", customer.getCustomerId());
	            return 0;
	        }
	    } catch (Exception e) {
	        logger.error("Error calculating arrears for customer {}: {}", customer.getCustomerId(), e.getMessage());
	        e.printStackTrace();
	        return 0;
	    }
	}
	public List<BillGetDto> getAllBills() {
		try {
			List<Bill> allBills = billRepository.findAll();
			List<BillGetDto> response = Mapper.INSTANCE.getAllBillsToEntity(allBills);
			logger.info("{} <<:getAllBills:Response:{}", response);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return new ArrayList<>();
		}
	}

	public long updateBill(BillGetDto updateDto) {
		Bill bill = null;
		try {
			logger.info("{}<<:updateDto:[{}]", updateDto);
			if (updateDto.getBillId() != null && updateDto.getBillId() > 0) {
				bill = billRepository.getOne(updateDto.getBillId());
			}
			if (bill != null) {
				Customer cust = customerRepository.getOne(updateDto.getCustomerId());
				if (cust == null) {
					throw new EntityNotFoundException("Customer not found with ID: " + updateDto.getCustomerId());
				}
				Bill billDto = Mapper.INSTANCE.updateDtoToBill(updateDto);
				billDto.setCustomer(cust);
				;
				logger.info("{}<<:updateBill:[{}]", billDto);
				billDto = billRepository.saveAndFlush(billDto);
				return billDto.getBillId();
			} else {
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}

	public long deleteBillById(Long id) {
		try {
			logger.info("{} >> deleteBillById:[{}],", id);
			billRepository.deleteById(id);
			return id;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}

	public double payBill(PaymentDto paymentRequest) {
		try {
			double outstandingAmount = getOutstandingAmount(paymentRequest.getCustomerId());
			 System.out.println("outstanding--->> "+outstandingAmount);
			logger.info("User {} has an outstanding amount of: {}", paymentRequest.getCustomerId(), outstandingAmount);
			double newOutstandingAmount = calculateNewOutstandingAmount(outstandingAmount,
					paymentRequest.getPaymentAmount());
			updateOutstandingAmount(paymentRequest.getCustomerId(), newOutstandingAmount);
			logger.info("Payment successful for user {}. New outstanding amount: {}", paymentRequest.getCustomerId(),
					newOutstandingAmount);
			return newOutstandingAmount;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Failed to process payment for user {}: {}", paymentRequest.getCustomerId(), e.getMessage(),e);
			return 0;
		}
	}

	private double getOutstandingAmount(Long customerId) {
	    try {
	        Optional<Bill> optionalBill = billRepository.findByCustomerId(customerId);
	        if (optionalBill.isPresent()) {
	            return optionalBill.get().getOutstandingAmount();
	        } else {
	            logger.info("No bill found for customer with ID: {}", customerId);
	            return 0.0;
	        }
	    } catch (Exception e) {
	    	logger.error("Error retrieving outstanding amount for customer with ID {}: {}", customerId, e.getMessage(), e);
	        return 0.0;
	    }
	}
	private double calculateNewOutstandingAmount(double currentOutstandingAmount, double paymentAmount) {
	    return Math.max(0, currentOutstandingAmount - paymentAmount);
	}

	private void updateOutstandingAmount(Long customerId, double newOutstandingAmount) {
	    Optional<Bill> optionalBill = billRepository.findByCustomerId(customerId);
	    optionalBill.ifPresent(bill -> {
	        bill.setOutstandingAmount(newOutstandingAmount);
	        billRepository.save(bill);
	    });
	}

	 public Map<Long, Double> calculatePendingDues(Long customerId) {
	        Map<Long, Double> pendingDuesByCustomerId = new HashMap<>();
	        try {
	            List<Bill> billsWithPendingDues = billRepository.findBillsWithPendingDues(customerId);
	            logger.info("billsWithPendingDues: {}", billsWithPendingDues);
	            for (Bill bill : billsWithPendingDues) {
	                Long customer = bill.getCustomer().getCustomerId();
	                Double totalAmount = bill.getBillAmount();
	                Double paidAmount = bill.getPaymentAmount();
	                Double pendingDueAmount = totalAmount - paidAmount;
	                pendingDuesByCustomerId.put(customer, pendingDueAmount);
	            }
	            return pendingDuesByCustomerId;
	        } catch (Exception e) {
	            e.printStackTrace();
	            logger.error("Error occurred while calculating pending dues for customer ID: {}", customerId, e);
	            return null;
	        }
	    }
}