package com.Management.BillManagementdetails.dto;

import java.util.Date;

public class PaymentDto {
	
	private Long customerId;
    private Double paymentAmount;
    private Date paymentDate;
    
	public PaymentDto() {
		super();
	}
	
	public PaymentDto(Long customerId, Double paymentAmount, Date paymentDate) {
		super();
		this.customerId = customerId;
		this.paymentAmount = paymentAmount;
		this.paymentDate = paymentDate;
	}

	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public Double getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(Double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	
	public Date getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}
	@Override
	public String toString() {
		return "PaymentDto [customerId=" + customerId + ", paymentAmount=" + paymentAmount + ", paymentDate=" + paymentDate
				+ "]";
	}
    
}
