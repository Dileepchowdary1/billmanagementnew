package com.Management.BillManagementdetails.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="user_Usage")
public class Usage implements Serializable{
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "usage_id")
    private Long usageId;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @Column(name = "usage_type")
    private String usageType;

    @Column(name = "measurement_unit")
    private String measurementUnit;

    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "quantity")
    private Double quantity;

    @Column(name = "timestamp")
    private Date timestamp;
    
	public Usage() {
	}


	public Usage(Long usageId, Customer customer, String usageType, String measurementUnit, String phoneNumber,
			Double quantity, Date timestamp) {
		super();
		this.usageId = usageId;
		this.customer = customer;
		this.usageType = usageType;
		this.measurementUnit = measurementUnit;
		this.phoneNumber = phoneNumber;
		this.quantity = quantity;
		this.timestamp = timestamp;
	}

	public Long getUsageId() {
		return usageId;
	}


	public void setUsageId(Long usageId) {
		this.usageId = usageId;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public String getUsageType() {
		return usageType;
	}

	public void setUsageType(String usageType) {
		this.usageType = usageType;
	}

	public String getMeasurementUnit() {
		return measurementUnit;
	}

	public void setMeasurementUnit(String measurementUnit) {
		this.measurementUnit = measurementUnit;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public String toString() {
		return "Usage [usageId=" + usageId + ", customer=" + customer + ", usageType=" + usageType + ", measurementUnit="
				+ measurementUnit + ", phoneNumber=" + phoneNumber + ", quantity=" + quantity + ", timestamp="
				+ timestamp + "]";
	}

}
