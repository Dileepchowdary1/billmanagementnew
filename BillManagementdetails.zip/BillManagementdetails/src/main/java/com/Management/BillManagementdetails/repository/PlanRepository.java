package com.Management.BillManagementdetails.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Management.BillManagementdetails.dto.PlanGetDto;
import com.Management.BillManagementdetails.entity.Plan;

@Repository
public interface PlanRepository extends JpaRepository<Plan,Long> {

	@Query("select tbl from Plan tbl where tbl.planId=:planId")
	public PlanGetDto getPlansByPlanId(@Param("planId") Long planId);
	

	
	

}
