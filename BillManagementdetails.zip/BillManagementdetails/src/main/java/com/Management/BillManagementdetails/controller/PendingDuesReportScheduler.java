package com.Management.BillManagementdetails.controller;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.Management.BillManagementdetails.service.BillService;

@Component
public class PendingDuesReportScheduler {

	public static final Logger logger = LogManager.getLogger(PendingDuesReportScheduler.class);
	@Autowired
	private BillService billingService;

	  public void generatePendingDuesReport(Long customerId) {
	        try {
	            Map<Long, Double> pendingDuesByCustomerId = billingService.calculatePendingDues(customerId);
	            for (Map.Entry<Long, Double> entry : pendingDuesByCustomerId.entrySet()) {
	                Long customer = entry.getKey();
	                Double pendingDueAmount = entry.getValue();
	                logger.info("Customer {} has pending due amount: {}", customer, pendingDueAmount);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        	logger.error("Error occurred while generating pending dues report", e);
	        }
	    }

}
