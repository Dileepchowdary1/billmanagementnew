package com.Management.BillManagementdetails.dto;

import java.util.Date;


public class BillDto {
	
    private Long customerId;
    private Double billAmount;
    private Date dueDate;
    private double paymentAmount;

		public BillDto() {
			super();
		}

		public BillDto(Long customerId, Double billAmount, Date dueDate,double paymentAmount) {
			super();
			this.customerId = customerId;
			this.billAmount = billAmount;
			this.dueDate = dueDate;
			this.paymentAmount=paymentAmount;
		}

		public Long getCustomerId() {
			return customerId;
		}

		public void setCustomerId(Long customerId) {
			this.customerId = customerId;
		}

		public Double getBillAmount() {
			return billAmount;
		}

		public void setBillAmount(Double billAmount) {
			this.billAmount = billAmount;
		}

		public Date getDueDate() {
			return dueDate;
		}

		public void setDueDate(Date dueDate) {
			this.dueDate = dueDate;
		}

		public double getPaymentAmount() {
			return paymentAmount;
		}

		public void setPaymentAmount(double paymentAmount) {
			this.paymentAmount = paymentAmount;
		}

		@Override
		public String toString() {
			return "BillDto [customerId=" + customerId + ", billAmount=" + billAmount + ", dueDate=" + dueDate
					+ ", paymentAmount=" + paymentAmount + "]";
		}

	    
}
