package com.Management.BillManagementdetails.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Management.BillManagementdetails.dto.BillGetDto;
import com.Management.BillManagementdetails.dto.CustomerGetDto;
import com.Management.BillManagementdetails.dto.PaymentDto;
import com.Management.BillManagementdetails.dto.ResponseDto;
import com.Management.BillManagementdetails.service.BillService;

@RestController
@RequestMapping("bills/")
public class BillingController {
	
	public static final Logger logger = LogManager.getLogger(BillingController.class);
	
	@Autowired
	BillService billService;
	
	   @PostMapping(path="/generate/{customerId}", produces = {"application/json", "application/xml"})
	    public ResponseEntity<ResponseDto> generateBill(@PathVariable Long customerId) {
	        try {
	            logger.info("GenerateBill >> CustomerId: [{}], BillingRequest: [{}]", customerId);
	            double billAmount = billService.generateBill(customerId);
	            logger.info("GenerateBill << BillAmount: [{}]", billAmount);
	            if (billAmount > 0) {
	                return ResponseEntity.ok(new ResponseDto((long) billAmount, "Bill generated successfully"));
	            } else {
	            	return ResponseEntity.ok(new ResponseDto((long) billAmount, "Bill generated failed"));
	            }
	        } catch (Exception e) {
	            logger.error("Error generating bill", e);
	            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	    }
	   
	   @GetMapping(path = "getallbills", produces = { "application/json", "application/xml" })
		public ResponseEntity<List<BillGetDto>> getAllBills() {
			try {
				List<BillGetDto> response = billService.getAllBills();
				logger.info("{} <<:getAllBills:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Exception:{}", e.getMessage());
				return ResponseEntity.status(HttpStatus.OK).body(new ArrayList<>());
			}
		}
	   @PutMapping(path = "updatebill/{id}", produces = { "application/json", "application/xml" })
		public ResponseEntity<ResponseDto> updateBill(@RequestBody BillGetDto updateDto) {
			ResponseDto response = null;
			try {
				long id = billService.updateBill(updateDto);
				if (id > 0) {
					response = new ResponseDto(id, "Bill update Successfully");
					logger.info("{} <<:update:Response:{}", response);
					return ResponseEntity.status(HttpStatus.OK).body(response);
				} else {
					response = new ResponseDto(id, "Bill update failed");
					logger.info("{} <<:update:Response:{}", response);
					return ResponseEntity.status(HttpStatus.OK).body(response);
				}
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Exception: {}", e.getMessage());
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
			}
		}
	   
	   @DeleteMapping(path = "deletebill/{id}", produces = { "application/json", "application/xml" })
		public ResponseEntity<ResponseDto> deleteBill(@PathVariable("id") Long id) {
			ResponseDto response = null;
			try {
				long billId = billService.deleteBillById(id);
				if (billId > 0) {
					response = new ResponseDto(id, "Bill deleted Successfully");
					logger.info("{} <<:deleteBill:Response:{}", response);
					return ResponseEntity.status(HttpStatus.OK).body(response);
				} else {
					response = new ResponseDto(id, "Bill fail to delete");
					logger.info("{} <<:deleteBill:Response:{}", response);
					return ResponseEntity.status(HttpStatus.OK).body(response);
				}
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Exception: {}", e.getMessage());
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
			}
		}
	   
	   
	   @PostMapping(path="pay", produces = {"application/json", "application/xml"})
	   public ResponseEntity<ResponseDto> payBill(@RequestBody PaymentDto paymentRequest) {
		   ResponseDto response = null;
	        try {
	            double outstanding = billService.payBill(paymentRequest);
	           
	            if(outstanding>0) {
	            	response =new ResponseDto((long) outstanding, "Payment successfully.Outstanding amount");
					logger.info("{} <<:deleteBill:Response:{}", response);
					return ResponseEntity.status(HttpStatus.OK).body(response);
	            }else {
	            	response =new ResponseDto((long) outstanding, "Payment failed.");
					logger.info("{} <<:deleteBill:Response:{}", response);
					return ResponseEntity.status(HttpStatus.OK).body(response);
	            }
	        } catch (Exception e) {
	        	return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
	        }
	    }

}
