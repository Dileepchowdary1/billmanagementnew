package com.Management.BillManagementdetails.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.Management.BillManagementdetails.dto.ResponseDto;
import com.Management.BillManagementdetails.dto.UsageCrtDto;
import com.Management.BillManagementdetails.dto.UsageGetDto;
import com.Management.BillManagementdetails.service.UsageService;

@RestController
@RequestMapping("usage/")
public class UsageController {

	public static final Logger logger = LogManager.getLogger(UsageController.class);

	@Autowired
	UsageService usageService;

	@PostMapping(path = "addusage", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> addUsage(@RequestBody UsageCrtDto crtDto) {
		ResponseDto response = null;
		try {
			long id = usageService.addUsage(crtDto);
			if (id > 0) {
				 response = new ResponseDto(id, "Usage created Successfully");
				logger.info("{} << response:[{}]", response);
				return new ResponseEntity<>(response, HttpStatus.CREATED);
			} else {
				 response = new ResponseDto(id, "Usage created failed");
				logger.info("{} << response:[{}]", response);
				return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error saving Usage", e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(path = "getallusages", produces = { "application/json", "application/xml" })
	public ResponseEntity<List<UsageGetDto>> getAllUsages() {
		try {
			List<UsageGetDto> response = usageService.getAllUsages();
			logger.info("{} <<:getAllUsages:Response:{}", response);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception:{}", e.getMessage());
			return ResponseEntity.status(HttpStatus.OK).body(new ArrayList<>());
		}
	}
	@PutMapping(path = "updatecustomer/{id}", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> updateUsage(@RequestBody UsageGetDto updateDto) {
		ResponseDto response = null;
		try {
			long id = usageService.updateUsages(updateDto);
			if (id > 0) {
				response = new ResponseDto(id, "Usages update Successfully");
				logger.info("{} <<:update:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else {
				response = new ResponseDto(id, "Usages update failed");
				logger.info("{} <<:update:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
		}
	}
	
	@DeleteMapping(path = "deleteusages/{id}", produces = { "application/json", "application/xml" })
	public ResponseEntity<ResponseDto> deleteUsage(@PathVariable("id") Long id) {
		ResponseDto response = null;
		try {
			long usageId = usageService.deleteUsagesById(id);
			if (usageId > 0) {
				response = new ResponseDto(id, "Usages deleted Successfully");
				logger.info("{} <<:deleteUsage:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else {
				response = new ResponseDto(id, "Usages fail to delete");
				logger.info("{} <<:deleteUsage:Response:{}", response);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ResponseDto());
		}
	}
	
	@GetMapping(path = "/getById/{id}", produces = { "application/json", "application/xml" })
    public ResponseEntity<UsageGetDto> getUsagesById(@PathVariable("id")  Long id) {
        try {
        	UsageGetDto response = usageService.getUsagesById(id);
            if (response != null) {
                logger.info(">>getUsagesById:[{}]", response);
                return ResponseEntity.status(HttpStatus.OK).body(response);
            } else {
                logger.info("{} <<:getUsagesById:Response:{}", response);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
	
	
}
