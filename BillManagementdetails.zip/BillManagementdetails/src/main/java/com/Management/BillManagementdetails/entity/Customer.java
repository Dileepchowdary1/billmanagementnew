package com.Management.BillManagementdetails.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class Customer implements Serializable {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "customer_id")
    private Long customerId;

    @OneToMany(mappedBy = "customer")
    private List<Usage> usages;

    @OneToMany(mappedBy = "customer")
    private List<Bill> bills;

//    @OneToMany(mappedBy = "customer")
//    private List<Payment> payments;

    @ManyToOne
    @JoinColumn(name = "plan_id")
    private Plan plan;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "email")
    private String email;

    @Column(name = "address")
    private String address;

//	public Customer(Long customerId, List<Usage> usages, List<Bill> bills, List<Payment> payments, Plan plan,
//			String customerName, String phoneNumber, String email, String address) {
//		super();
//		this.customerId = customerId;
//		this.usages = usages;
//		this.bills = bills;
//		this.payments = payments;
//		this.plan = plan;
//		this.customerName = customerName;
//		this.phoneNumber = phoneNumber;
//		this.email = email;
//		this.address = address;
//	}

	public Customer() {
		super();
	}

	public Customer(Long customerId, List<Usage> usages, List<Bill> bills, Plan plan, String customerName,
			String phoneNumber, String email, String address) {
		super();
		this.customerId = customerId;
		this.usages = usages;
		this.bills = bills;
		this.plan = plan;
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.address = address;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public List<Usage> getUsages() {
		return usages;
	}

	public void setUsages(List<Usage> usages) {
		this.usages = usages;
	}

	public List<Bill> getBills() {
		return bills;
	}

	public void setBills(List<Bill> bills) {
		this.bills = bills;
	}

//	public List<Payment> getPayments() {
//		return payments;
//	}
//
//	public void setPayments(List<Payment> payments) {
//		this.payments = payments;
//	}

	public Plan getPlan() {
		return plan;
	}

	public void setPlan(Plan plan) {
		this.plan = plan;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", usages=" + usages + ", bills=" + bills + ", plan=" + plan
				+ ", customerName=" + customerName + ", phoneNumber=" + phoneNumber + ", email=" + email + ", address="
				+ address + "]";
	}

}
