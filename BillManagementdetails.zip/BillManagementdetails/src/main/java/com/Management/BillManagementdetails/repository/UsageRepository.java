package com.Management.BillManagementdetails.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Management.BillManagementdetails.entity.Usage;

@Repository
public interface UsageRepository extends JpaRepository<Usage,Long>{
	
//	List<Usage> findByCustomerIdAndTimestampBetween(Long customerId, LocalDateTime startTime, LocalDateTime endTime);
	
	@Query("SELECT u FROM Usage u WHERE u.customer.customerId = :customerId AND u.timestamp BETWEEN :startTime AND :endTime")
	    List<Usage> findByCustomerIdAndTimestampBetween(@Param("customerId") Long customerId, @Param("startTime") LocalDateTime startTime,
	            @Param("endTime") LocalDateTime endTime);

	@Query("select tbl from Usage tbl where tbl.usageId=:usageId")
	public Usage getUsagesById(@Param("usageId") Long usageId);

	
	

//	 @Query("SELECT u FROM Usage u WHERE u.paymentStatus = 'PENDING'")
//    List<Usage> findUsagesWithPendingDues();


}
