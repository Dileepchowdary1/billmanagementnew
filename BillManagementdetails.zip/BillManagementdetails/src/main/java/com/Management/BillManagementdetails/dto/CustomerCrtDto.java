package com.Management.BillManagementdetails.dto;

public class CustomerCrtDto {
	
	private String customerName;
	private String phoneNumber;
	private String email;
	private Long planId;
	 private String address;
	public CustomerCrtDto() {
		super();
	}
	public CustomerCrtDto(String customerName, String phoneNumber, String email, Long planId,String address) {
		super();
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.planId=planId;
		this.address=address;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public Long getPlanId() {
		return planId;
	}
	public void setPlanId(Long planId) {
		this.planId = planId;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "CustomerCrtDto [customerName=" + customerName + ", phoneNumber=" + phoneNumber + ", email=" + email
				+ ", planId=" + planId + ", address=" + address + "]";
	}
	

}
