package com.Management.BillManagementdetails.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Management.BillManagementdetails.entity.Bill;
import com.Management.BillManagementdetails.entity.Customer;

@Repository
public interface BillRepository extends JpaRepository<Bill,Long>{

	 
	 @Query("SELECT b FROM Bill b WHERE b.customer.customerId = :customerId")
	 Optional<Bill> findByCustomerId(@Param("customerId") Long customerId);
	 
	 @Query("SELECT b FROM Bill b WHERE b.customer = :customer AND b.dueDate BETWEEN :startDate AND :endDate")
	 List<Bill> findByCustomerAndDueDateBetween(@Param("customer") Customer customer,
	                                                 @Param("startDate") Date startDate,
	                                                 @Param("endDate") Date endDate);

	 @Query("SELECT b FROM Bill b WHERE b.billAmount = :billAmount")
	List<Bill> findByBillAmountGreaterThan(@Param("billAmount")double billAmount);
	 
	 @Query("SELECT b FROM Bill b WHERE b.customer = :customer ORDER BY b.dueDate DESC")
	  Bill findBillForCustomer(@Param("customer") Customer customer);

	  // Assuming there is a bidirectional relationship between Bill and Customer
    @Query("SELECT b FROM Bill b WHERE b.customer.customerId = :customerId AND b.billAmount > b.paymentAmount")
    List<Bill> findBillsWithPendingDues(@Param("customerId") Long customerId);



	 
}
