package com.Management.BillManagementdetails.dto;

public class CustomerGetDto {

	private Long customerId;
	private String customerName;
	private String phoneNumber;
	private String email;
	private Long planId;
	public CustomerGetDto() {
		super();
	}
	public CustomerGetDto(Long customerId, String customerName, String phoneNumber, String email, Long planId) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.planId = planId;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getPlanId() {
		return planId;
	}
	public void setPlanId(Long planId) {
		this.planId = planId;
	}
	@Override
	public String toString() {
		return "CustomerGetDto [customerId=" + customerId + ", customerName=" + customerName + ", phoneNumber="
				+ phoneNumber + ", email=" + email + ", planId=" + planId + "]";
	}
	
}
