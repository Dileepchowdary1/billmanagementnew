package com.Management.BillManagementdetails.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Management.BillManagementdetails.dto.CustomerGetDto;
import com.Management.BillManagementdetails.dto.UsageCrtDto;
import com.Management.BillManagementdetails.dto.UsageGetDto;
import com.Management.BillManagementdetails.entity.Customer;
import com.Management.BillManagementdetails.entity.Plan;
import com.Management.BillManagementdetails.entity.Usage;
import com.Management.BillManagementdetails.mapper.Mapper;
import com.Management.BillManagementdetails.repository.CustomerRepo;
import com.Management.BillManagementdetails.repository.UsageRepository;

@Service
public class UsageService {

	public static final Logger logger = LogManager.getLogger(UsageService.class);
	@Autowired
	UsageRepository usageRepository;

	@Autowired
	CustomerRepo customerRepository;

	public long addUsage(UsageCrtDto crtDto) {
		try {
			Usage response = null;
			Customer customer = customerRepository.getOne(crtDto.getCustomerId());
			if (customer.getCustomerId() > 0) {
				Usage usage = new Usage();
				usage.setCustomer(customer);
				usage.setUsageType(crtDto.getUsageType());
				usage.setMeasurementUnit(crtDto.getMeasurementUnit());
				usage.setPhoneNumber(crtDto.getPhoneNumber());
				usage.setQuantity(crtDto.getQuantity());
				usage.setTimestamp(new Date());
				response = usageRepository.save(usage);
				return response.getUsageId();
			} else {
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error adding usage", e);
			return 0;
		}
	}

	public List<UsageGetDto> getAllUsages() {
		try {
			List<Usage> allUsages = usageRepository.findAll();
			List<UsageGetDto> response = Mapper.INSTANCE.getAllUsagesToEntity(allUsages);
			logger.info("{} <<:getAllUsages:Response:{}", response);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return new ArrayList<>();
		}
	}

	public long updateUsages(UsageGetDto updateDto) {
		Usage usage = null;
		try {
			if (updateDto.getUsageId() != null && updateDto.getUsageId() > 0) {
				usage = usageRepository.getUsagesById(updateDto.getUsageId());
			}
			if (usage != null) {
				 Customer cust=customerRepository.getOne(updateDto.getCustomerId());
				 if (cust == null) {
	                    throw new EntityNotFoundException("Customer not found with ID: " + updateDto.getCustomerId());
	                }
				 Usage usageDto = Mapper.INSTANCE.updateDtoToUsage(updateDto);
				 usageDto.setCustomer(cust);
				logger.info("{}<<:updateUsage:[{}]", usageDto);
				usageDto = usageRepository.saveAndFlush(usageDto);
				return usageDto.getUsageId();
			} else {
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}
	
	public long deleteUsagesById(Long id) {
		try {
			logger.info("{} >> deleteUsagesById:[{}],", id);
			usageRepository.deleteById(id);
			return id;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}
	public UsageGetDto getUsagesById(Long id) {
		try {
			Usage response = usageRepository.getUsagesById(id);
			if (response.getCustomer() != null) {
				UsageGetDto dto = new UsageGetDto(response.getUsageId(), response.getCustomer().getCustomerId(),
						response.getUsageType(), response.getMeasurementUnit(), response.getPhoneNumber(),response.getQuantity(),
						response.getTimestamp());
				logger.info("{} <<:getUsagesById:Response:{}", dto);
				return dto;
			} else {
				logger.info("Usage is null for usageId: {}", id);
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return null;
		}
	}
}
