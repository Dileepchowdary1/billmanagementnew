package com.Management.BillManagementdetails.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.Management.BillManagementdetails.entity.Usage;
import com.Management.BillManagementdetails.repository.UsageRepository;
import com.Management.BillManagementdetails.service.PlanService;

@Component
public class CallMetricsScheduler {

	
	public static final Logger logger = LogManager.getLogger(CallMetricsScheduler.class);
	
	@Autowired
	PlanService planService;
	@Autowired
	UsageRepository usageRepository;
	
	@Scheduled(cron = "0 0 0 * * MON") 
    public void generateUsageMetricsReport() {
        try {
            Map<String, Long> usageMetrics = calculateUsageMetrics();
            logger.info("Metrics Report - STD Calls: {}, ISD Calls: {}", usageMetrics.get("STD_CALL"), usageMetrics.get("ISD_CALL"));
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Error occurred while generating usage metrics report", e);
        }
    }
	
	private Map<String, Long> calculateUsageMetrics() {
        Map<String, Long> usageMetrics = new HashMap<>();
        List<Usage> allUsages = usageRepository.findAll();
        long stdCallCount = 0;
        long isdCallCount = 0;
        for (Usage usage : allUsages) {
            if ("stdcall".equalsIgnoreCase(usage.getUsageType())) {
                stdCallCount += usage.getQuantity();
            } else if ("isDCALL".equalsIgnoreCase(usage.getUsageType())) {
                isdCallCount += usage.getQuantity();
            }
        }
        usageMetrics.put("STD_CALL", stdCallCount);
        usageMetrics.put("ISD_CALL", isdCallCount);

        return usageMetrics;
    }
	
}
