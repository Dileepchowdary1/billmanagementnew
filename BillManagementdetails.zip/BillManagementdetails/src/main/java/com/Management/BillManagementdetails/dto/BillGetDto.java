package com.Management.BillManagementdetails.dto;

import java.util.Date;

public class BillGetDto {
	

	private Long billId;
	private Long customerId;
    private Double billAmount;
    private Date dueDate;
    private Double outstandingAmount;
    private double paymentAmount;
    
	public BillGetDto(Long billId, Long customerId, Double billAmount, Date dueDate,Double outstandingAmount,double paymentAmount) {
		super();
		this.billId = billId;
		this.customerId = customerId;
		this.billAmount = billAmount;
		this.dueDate = dueDate;
		this.outstandingAmount=outstandingAmount;
		this.paymentAmount=paymentAmount;
	}
	public BillGetDto() {
		super();
	}
	
	
	public Long getBillId() {
		return billId;
	}
	public void setBillId(Long billId) {
		this.billId = billId;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public Double getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(Double billAmount) {
		this.billAmount = billAmount;
	}
	public Date getDueDate() {
		return dueDate;
	}
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	
	public Double getOutstandingAmount() {
		return outstandingAmount;
	}
	public void setOutstandingAmount(Double outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}
	public double getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	@Override
	public String toString() {
		return "BillGetDto [billId=" + billId + ", customerId=" + customerId + ", billAmount=" + billAmount
				+ ", dueDate=" + dueDate + ", outstandingAmount=" + outstandingAmount + ", paymentAmount="
				+ paymentAmount + "]";
	}
	
}
