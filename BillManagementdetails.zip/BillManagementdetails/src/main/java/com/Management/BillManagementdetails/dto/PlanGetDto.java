package com.Management.BillManagementdetails.dto;

public class PlanGetDto {
	
		private Long planId;
	    private Double stdCallCharges;
	    private Double quantityStdCall;
	    private String unitStdCall;
	    private Double freeUnitStdCall;
	    private Double isdCallCharges;
	    private Double quantityIsdCall;
	    private String unitIsdCall;
	    private Double freeUnitIsdCall;
	    private Double stdSmsCharges;
	    private Double freeUnitStdSms;
	    private Double isdSmsCharges;
	    private Double freeUnitIsdSms;
	    private Double dataCharges;
	    private String dataChargesUnit;
	    private Double freeUnitData;
		public PlanGetDto(Long planId, Double stdCallCharges, Double quantityStdCall, String unitStdCall,
				Double freeUnitStdCall, Double isdCallCharges, Double quantityIsdCall, String unitIsdCall,
				Double freeUnitIsdCall, Double stdSmsCharges, Double freeUnitStdSms, Double isdSmsCharges,
				Double freeUnitIsdSms, Double dataCharges, String dataChargesUnit, Double freeUnitData) {
			super();
			this.planId = planId;
			this.stdCallCharges = stdCallCharges;
			this.quantityStdCall = quantityStdCall;
			this.unitStdCall = unitStdCall;
			this.freeUnitStdCall = freeUnitStdCall;
			this.isdCallCharges = isdCallCharges;
			this.quantityIsdCall = quantityIsdCall;
			this.unitIsdCall = unitIsdCall;
			this.freeUnitIsdCall = freeUnitIsdCall;
			this.stdSmsCharges = stdSmsCharges;
			this.freeUnitStdSms = freeUnitStdSms;
			this.isdSmsCharges = isdSmsCharges;
			this.freeUnitIsdSms = freeUnitIsdSms;
			this.dataCharges = dataCharges;
			this.dataChargesUnit = dataChargesUnit;
			this.freeUnitData = freeUnitData;
		}
		public PlanGetDto() {
			super();
		}
		public Long getPlanId() {
			return planId;
		}
		public void setPlanId(Long planId) {
			this.planId = planId;
		}
		public Double getStdCallCharges() {
			return stdCallCharges;
		}
		public void setStdCallCharges(Double stdCallCharges) {
			this.stdCallCharges = stdCallCharges;
		}
		public Double getQuantityStdCall() {
			return quantityStdCall;
		}
		public void setQuantityStdCall(Double quantityStdCall) {
			this.quantityStdCall = quantityStdCall;
		}
		public String getUnitStdCall() {
			return unitStdCall;
		}
		public void setUnitStdCall(String unitStdCall) {
			this.unitStdCall = unitStdCall;
		}
		public Double getFreeUnitStdCall() {
			return freeUnitStdCall;
		}
		public void setFreeUnitStdCall(Double freeUnitStdCall) {
			this.freeUnitStdCall = freeUnitStdCall;
		}
		public Double getIsdCallCharges() {
			return isdCallCharges;
		}
		public void setIsdCallCharges(Double isdCallCharges) {
			this.isdCallCharges = isdCallCharges;
		}
		public Double getQuantityIsdCall() {
			return quantityIsdCall;
		}
		public void setQuantityIsdCall(Double quantityIsdCall) {
			this.quantityIsdCall = quantityIsdCall;
		}
		public String getUnitIsdCall() {
			return unitIsdCall;
		}
		public void setUnitIsdCall(String unitIsdCall) {
			this.unitIsdCall = unitIsdCall;
		}
		public Double getFreeUnitIsdCall() {
			return freeUnitIsdCall;
		}
		public void setFreeUnitIsdCall(Double freeUnitIsdCall) {
			this.freeUnitIsdCall = freeUnitIsdCall;
		}
		public Double getStdSmsCharges() {
			return stdSmsCharges;
		}
		public void setStdSmsCharges(Double stdSmsCharges) {
			this.stdSmsCharges = stdSmsCharges;
		}
		public Double getFreeUnitStdSms() {
			return freeUnitStdSms;
		}
		public void setFreeUnitStdSms(Double freeUnitStdSms) {
			this.freeUnitStdSms = freeUnitStdSms;
		}
		public Double getIsdSmsCharges() {
			return isdSmsCharges;
		}
		public void setIsdSmsCharges(Double isdSmsCharges) {
			this.isdSmsCharges = isdSmsCharges;
		}
		public Double getFreeUnitIsdSms() {
			return freeUnitIsdSms;
		}
		public void setFreeUnitIsdSms(Double freeUnitIsdSms) {
			this.freeUnitIsdSms = freeUnitIsdSms;
		}
		public Double getDataCharges() {
			return dataCharges;
		}
		public void setDataCharges(Double dataCharges) {
			this.dataCharges = dataCharges;
		}
		public String getDataChargesUnit() {
			return dataChargesUnit;
		}
		public void setDataChargesUnit(String dataChargesUnit) {
			this.dataChargesUnit = dataChargesUnit;
		}
		public Double getFreeUnitData() {
			return freeUnitData;
		}
		public void setFreeUnitData(Double freeUnitData) {
			this.freeUnitData = freeUnitData;
		}
		@Override
		public String toString() {
			return "PlanGetDto [planId=" + planId + ", stdCallCharges=" + stdCallCharges + ", quantityStdCall="
					+ quantityStdCall + ", unitStdCall=" + unitStdCall + ", freeUnitStdCall=" + freeUnitStdCall
					+ ", isdCallCharges=" + isdCallCharges + ", quantityIsdCall=" + quantityIsdCall + ", unitIsdCall="
					+ unitIsdCall + ", freeUnitIsdCall=" + freeUnitIsdCall + ", stdSmsCharges=" + stdSmsCharges
					+ ", freeUnitStdSms=" + freeUnitStdSms + ", isdSmsCharges=" + isdSmsCharges + ", freeUnitIsdSms="
					+ freeUnitIsdSms + ", dataCharges=" + dataCharges + ", dataChargesUnit=" + dataChargesUnit
					+ ", freeUnitData=" + freeUnitData + "]";
		}
	    
}
