package com.Management.BillManagementdetails.mapper;

import java.util.List;

import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import com.Management.BillManagementdetails.dto.BillGetDto;
import com.Management.BillManagementdetails.dto.CustomerGetDto;
import com.Management.BillManagementdetails.dto.PlanCrtDto;
import com.Management.BillManagementdetails.dto.PlanGetDto;
import com.Management.BillManagementdetails.dto.UsageGetDto;
import com.Management.BillManagementdetails.entity.Bill;
import com.Management.BillManagementdetails.entity.Customer;
import com.Management.BillManagementdetails.entity.Plan;
import com.Management.BillManagementdetails.entity.Usage;

@org.mapstruct.Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = "String")
public interface Mapper {
	
	Mapper INSTANCE = Mappers.getMapper(Mapper.class);

	Plan planCrtDtoToPlanEntity(PlanCrtDto crtDto);

	Customer updateDtoToCustomer(CustomerGetDto updateDto);

	List<UsageGetDto> getAllUsagesToEntity(List<Usage> allUsages);

	Usage updateDtoToUsage(UsageGetDto updateDto);

	List<PlanGetDto> getAllPlansToEntity(List<Plan> allPlans);

	Plan updateDtoToPlan(PlanGetDto updateDto);

	List<BillGetDto> getAllBillsToEntity(List<Bill> allBills);

	Bill updateDtoToBill(BillGetDto updateDto);
	
}
