//package com.Management.BillManagementdetails.service;
//
//import java.time.LocalDate;
//import java.util.Date;
//import java.util.List;
//
//import javax.persistence.EntityNotFoundException;
//
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.Management.BillManagementdetails.dto.PaymentDto;
//import com.Management.BillManagementdetails.entity.Bill;
//import com.Management.BillManagementdetails.entity.Customer;
//import com.Management.BillManagementdetails.entity.Payment;
//import com.Management.BillManagementdetails.repository.CustomerRepo;
//import com.Management.BillManagementdetails.repository.PaymentRepo;
//
//@Service
//public class PaymentService {
//
//	public static final Logger logger = LogManager.getLogger(PaymentService.class);
//
//	@Autowired
//	private CustomerRepo customerRepository;
//
//	@Autowired
//	PaymentRepo paymentRepository;
//
//	public double payBill(PaymentDto paymentDto) {
//		try {
//
//			Customer customer = customerRepository.getOne(paymentDto.getCustomerId());
//			System.out.println("customer" + customer);
//			if (customer.getCustomerId() > 0) {
//
//				// Check for any outstanding bills
//				double outstandingAmount = getOutstandingAmount(customer);
//
//				// Ensure that the payment amount does not exceed the outstanding amount
//				if (paymentDto.getPaymentAmount() > outstandingAmount) {
//					throw new RuntimeException("Payment amount exceeds outstanding amount");
//				}
//
//				// Create a new payment entry
//				Payment payment = new Payment();
//				payment.setCustomer(customer);
//				payment.setPaymentAmount(paymentDto.getPaymentAmount());
//				payment.setPaymentDate(new Date());
//
//				// Save the payment entry
//				paymentRepository.save(payment);
//
//				// Calculate the updated outstanding amount after the payment
//				outstandingAmount = getOutstandingAmount(customer);
//				return outstandingAmount;
//			} else {
//				return 0.0;
//			}
//		} catch (EntityNotFoundException e) {
//			// Log the exception
//			e.printStackTrace();
//			throw new RuntimeException("Customer not found with ID: " + paymentDto.getCustomerId(), e);
//		} catch (Exception e) {
//			// Log the exception
//			e.printStackTrace();
//			return 0.0;
//		}
//	}
//
//	private double getOutstandingAmount(Customer customer) {
//		double totalBillAmount = getTotalBillAmount(customer);
//		double totalPaidAmount = getTotalPaidAmount(customer);
//		return totalBillAmount - totalPaidAmount;
//	}
//	private double getTotalBillAmount(Customer customer) {
//		List<Bill> customerBills = customer.getBills();
//		double totalBillAmount = 0.0;
//		for (Bill bill : customerBills) {
//			totalBillAmount += bill.getBillAmount();
//		}
//
//		return totalBillAmount;
//	}
//
//	private double getTotalPaidAmount(Customer customer) {
//		List<Payment> customerPayments = customer.getPayments();
//		double totalPaidAmount = 0.0;
//
//		for (Payment payment : customerPayments) {
//			totalPaidAmount += payment.getPaymentAmount();
//		}
//		return totalPaidAmount;
//	}
//}
