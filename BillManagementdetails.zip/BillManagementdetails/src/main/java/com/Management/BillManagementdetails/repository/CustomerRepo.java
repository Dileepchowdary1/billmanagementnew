package com.Management.BillManagementdetails.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Management.BillManagementdetails.entity.Customer;

@Repository
public interface CustomerRepo extends JpaRepository<Customer,Long>{


	@Query("select tbl from Customer tbl where tbl.customerId=:customerId")
	public Customer getCustomersByCustomerId(@Param("customerId") Long customerId);

	@Query("select tbl.customerId, tbl.customerName,tbl.phoneNumber, tbl.email, tbl.plan.planId from Customer tbl")
    List<Object[]> findAllCustomers();
	
}
