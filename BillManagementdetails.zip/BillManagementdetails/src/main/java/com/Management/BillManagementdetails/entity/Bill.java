	package com.Management.BillManagementdetails.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="bill")
public class Bill implements Serializable{
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "bill_Id")
    private Long billId;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @Column(name = "bill_amount")
    private Double billAmount;

    @Column(name = "due_date")
    private Date dueDate;
    
    @Column(name = "outstanding_amount")
    private Double outstandingAmount;

    @Column(name = "payment_amount")
    private double paymentAmount;
    
	public Bill() {
		super();
	}

	public Bill(Long billId, Customer customer, Double billAmount, Date dueDate,Double outstandingAmount,double paymentAmount) {
		super();
		this.billId = billId;
		this.customer = customer;
		this.billAmount = billAmount;
		this.dueDate = dueDate;
		this.outstandingAmount=outstandingAmount;
		this.paymentAmount=paymentAmount;
	}


	public Long getBillId() {
		return billId;
	}

	public void setBillId(Long billId) {
		this.billId = billId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Double getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(Double billAmount) {
		this.billAmount = billAmount;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
	

	public Double getOutstandingAmount() {
		return outstandingAmount;
	}

	public void setOutstandingAmount(Double outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}
	

	public double getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	@Override
	public String toString() {
		return "Bill [billId=" + billId + ", customer=" + customer + ", billAmount=" + billAmount + ", dueDate="
				+ dueDate + ", outstandingAmount=" + outstandingAmount + ", paymentAmount=" + paymentAmount + "]";
	}

}
