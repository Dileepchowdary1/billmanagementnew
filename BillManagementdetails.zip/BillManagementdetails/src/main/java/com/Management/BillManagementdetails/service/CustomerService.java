package com.Management.BillManagementdetails.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.persistence.EntityNotFoundException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.Management.BillManagementdetails.dto.CustomerCrtDto;
import com.Management.BillManagementdetails.dto.CustomerGetDto;
import com.Management.BillManagementdetails.entity.Customer;
import com.Management.BillManagementdetails.entity.Plan;
import com.Management.BillManagementdetails.mapper.Mapper;
import com.Management.BillManagementdetails.repository.CustomerRepo;
import com.Management.BillManagementdetails.repository.PlanRepository;

@Service
public class CustomerService {

	public static final Logger logger = LogManager.getLogger(CustomerService.class);

	@Autowired
	CustomerRepo customerRepo;

	@Autowired
	private PlanRepository planRepository;

	public long saveCustomer(CustomerCrtDto dto) {
		try {
			logger.info("{} >> CreateCustomerDto:[{}],", dto);

			Customer customer = new Customer();
			customer.setCustomerName(dto.getCustomerName());
			customer.setPhoneNumber(dto.getPhoneNumber());
			customer.setEmail(dto.getEmail());
			customer.setAddress(dto.getAddress());
			if (dto.getPlanId() != null) {
				Plan plan = new Plan();
				plan.setPlanId(dto.getPlanId());
				customer.setPlan(plan);
			}
			Customer savedCustomer = customerRepo.save(customer);
			logger.info("{} >> custResp:[{}],", savedCustomer);
			return savedCustomer.getCustomerId();
		} catch (Exception e) {
			logger.error("Error saving customer", e);
			return 0;
		}
	}

	public List<CustomerGetDto> getAllCustomers() {
		try {

			List<Object[]> allCustomers = customerRepo.findAllCustomers();
			List<CustomerGetDto> response = allCustomers.stream().map(customerData -> {
				Long customerId = (Long) customerData[0];
				String customerName = (String) customerData[1];
				String phoneNumber = (String) customerData[2];
				String email = (String) customerData[3];
				Long planId = (Long) customerData[0];
				return new CustomerGetDto(customerId, customerName, phoneNumber, email, planId);
			}).collect(Collectors.toList());
			logger.info("{} <<:getAllCustomers:Response:{}", response);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return new ArrayList<>();
		}
	}

	public long updateCustomers(CustomerGetDto updateDto) {
		Customer cust = null;
		try {
			if (updateDto.getCustomerId() != null && updateDto.getCustomerId() > 0) {
				cust = customerRepo.getCustomersByCustomerId(updateDto.getCustomerId());
			}
			if (cust != null) {
				Plan plan = planRepository.getOne(updateDto.getPlanId());
				if (plan == null) {
					throw new EntityNotFoundException("Plan not found with ID: " + updateDto.getPlanId());
				}
				Customer custDto = Mapper.INSTANCE.updateDtoToCustomer(updateDto);
				custDto.setPlan(plan);
				logger.info("{}<<:updateCustomers:[{}]", custDto);
				custDto = customerRepo.saveAndFlush(custDto);
				return custDto.getCustomerId();
			} else {
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}

	public long deleteCustomerById(Long customerId) {
		try {
			logger.info("{} >> deleteCustomerById:[{}],", customerId);
			customerRepo.deleteById(customerId);
			return customerId;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return 0;
		}
	}

	public CustomerGetDto getByCustomerId(Long customerId) {
		try {
			Customer response = customerRepo.getCustomersByCustomerId(customerId);
			if (response.getPlan() != null) {
				CustomerGetDto dto = new CustomerGetDto(response.getCustomerId(), response.getCustomerName(),
						response.getPhoneNumber(), response.getEmail(), response.getPlan().getPlanId());
				logger.info("{} <<:getByMobileId:Response:{}", dto);
				return dto;
			} else {
				logger.info("Customer is null for customerId: {}", customerId);
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception: {}", e.getMessage());
			return null;
		}
	}

}
